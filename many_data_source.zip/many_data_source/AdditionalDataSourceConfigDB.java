package com.csi.csimappingresults.config;

import javax.sql.DataSource;
import java.util.concurrent.ConcurrentHashMap;

public class AdditionalDataSourceConfigDB {

    private static ConcurrentHashMap<Object, Object> ADDITIONAL_DATA_SOURCE_CACHE = new ConcurrentHashMap<>();

    private static final ThreadLocal<String> contextHolder = new ThreadLocal<>();

    public static void setDataSourceName(String name) {
        clearDataSourceName();
        contextHolder.set(name);
    }

    public static String getDataSourceName() {
        return contextHolder.get();
    }

    public static void clearDataSourceName() {
        contextHolder.remove();
    }


    public static DataSource getDataSource() {
        return getDataSource(contextHolder.get());
    }

    public static DataSource getDataSource(String databaseId){
        DataSource dataSource= (DataSource) ADDITIONAL_DATA_SOURCE_CACHE.get(databaseId);
        if(dataSource != null) {
            return dataSource;
        }
        // TODO add new dataSource
        //additionalDataSourceCache.put(databaseId, dataSource);

        return (DataSource) ADDITIONAL_DATA_SOURCE_CACHE.get("defaultDataSource");
    }

    public static void addDateSource(String name, DataSource dataSource){
        ADDITIONAL_DATA_SOURCE_CACHE.put(name, dataSource);
    }

}