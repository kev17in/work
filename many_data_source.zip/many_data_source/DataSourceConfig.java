package com.csi.csimappingresults.config;

import com.baomidou.dynamic.datasource.DynamicDataSourceCreator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import java.util.List;
import java.util.Map;

import static com.csi.csimappingresults.config.MyDynamicDataSourceProvider.DEFAULT_DATA_SOURCE_NAME;


@Configuration
@Primary
@Slf4j
public class DataSourceConfig {

   @Bean
   public MyDynamicDataSourceProvider myDynamicDataSourceProvider(DataSourceConfigValue dataSourceConfigValue, DynamicDataSourceCreator dynamicDataSourceCreator){
      List<MyDataSourceProperty> dataSourcePropertyList = dataSourceConfigValue.getDataSources();
      if(null == dataSourcePropertyList || dataSourcePropertyList.isEmpty()){
         log.error("read dataSource not is null");
         throw new RuntimeException("read dataSource not is null");
      }
      MyDataSourceProperty defaultDateSource = null;
      for (MyDataSourceProperty dataSourceConfig : dataSourcePropertyList) {
         if(dataSourceConfigValue.getDefaultDbName().equals(dataSourceConfig.getDbTypeName())){
            defaultDateSource = dataSourceConfig;
            break;
         }
      }
      if(defaultDateSource == null){
         defaultDateSource = dataSourcePropertyList.get(0);
      }
      defaultDateSource.setPollName(DEFAULT_DATA_SOURCE_NAME);
      //@DS("#dataSource.dbName") tran
      return new MyDynamicDataSourceProvider(dataSourcePropertyList, dynamicDataSourceCreator);
   }

   @Primary
   @Bean(name = "multiDataSource")
   public MultiRouteDataSource exampleRouteDataSource(MyDynamicDataSourceProvider myDynamicDataSourceProvider) {
      MultiRouteDataSource multiDataSource = new MultiRouteDataSource();
      Map<Object, Object> loadDataSources = myDynamicDataSourceProvider.loadDataSources();
      multiDataSource.setTargetDataSources(loadDataSources);
      //����Ĭ������Դ
      multiDataSource.setDefaultTargetDataSource(loadDataSources.get(DEFAULT_DATA_SOURCE_NAME));
      AdditionalDataSourceConfigDB.setDataSourceName(DEFAULT_DATA_SOURCE_NAME);
      return multiDataSource;
   }

}