package com.csi.csimappingresults.config;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

import javax.sql.DataSource;

public class MultiRouteDataSource extends AbstractRoutingDataSource {

    /**
     * return dataSourceName #AbstractRoutingDataSource.resolveSpecifiedDataSource()
     * @return
     */
    @Override
    protected Object determineCurrentLookupKey() {
        return AdditionalDataSourceConfigDB.getDataSourceName();
    }

    /*@Override
    protected DataSource determineTargetDataSource() {
        return AdditionalDataSourceConfigDB.getDataSource();
    }*/
}
