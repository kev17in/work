package com.csi.csimappingresults.config;

import com.baomidou.dynamic.datasource.spring.boot.autoconfigure.DataSourceProperty;
import lombok.Data;

@Data
public class MyDataSourceProperty extends DataSourceProperty {

    private String selectDbSql;

    private String dbTypeName;
}
