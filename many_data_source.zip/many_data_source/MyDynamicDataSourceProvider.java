package com.csi.csimappingresults.config;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.dynamic.datasource.DynamicDataSourceCreator;
import com.baomidou.dynamic.datasource.provider.DynamicDataSourceProvider;
import com.baomidou.dynamic.datasource.spring.boot.autoconfigure.DataSourceProperty;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.support.JdbcUtils;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Slf4j
public class MyDynamicDataSourceProvider {

    private final DynamicDataSourceCreator dynamicDataSourceCreator;

    public static final String DEFAULT_DATA_SOURCE_NAME = "defaultDataSource";
    public static final String SYBASE = "sybase";
    public static final String SQL_SERVER = "sqlServer";

    private final List<MyDataSourceProperty> dataSourcePropertyList = new ArrayList<>();

    public MyDynamicDataSourceProvider(List<MyDataSourceProperty> dataSourcePropertyList, DynamicDataSourceCreator dynamicDataSourceCreator) {
        this.dataSourcePropertyList.addAll(dataSourcePropertyList);
        this.dynamicDataSourceCreator = dynamicDataSourceCreator;
    }

    public Map<Object, Object> loadDataSources() {
        try {
            Map<String, DataSourceProperty> dataSourcePropertiesMap = executeStmt();
            Map<Object, Object> dataSourceMap = new HashMap<>(dataSourcePropertiesMap.size());
            dataSourcePropertiesMap.forEach((key, value) -> {
                DataSource dataSource = dynamicDataSourceCreator.createDataSource(value);
                dataSourceMap.put(key, dataSource);
                AdditionalDataSourceConfigDB.addDateSource(key, dataSource);
            });
            return dataSourceMap;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    protected Map<String, DataSourceProperty> executeStmt() throws Exception {
        Map<String, DataSourceProperty> allDataSourceConfigMap = new HashMap<>();
        for (MyDataSourceProperty dataSourceProperty : dataSourcePropertyList) {
            addDataSourceConfig(dataSourceProperty, allDataSourceConfigMap);
            //master
            if(DEFAULT_DATA_SOURCE_NAME.equals(dataSourceProperty.getPollName())){
                allDataSourceConfigMap.put(DEFAULT_DATA_SOURCE_NAME, dataSourceProperty);
            }
        }
        return allDataSourceConfigMap;
    }

    private void addDataSourceConfig(MyDataSourceProperty dataSourceProperty, Map<String, DataSourceProperty> allDataSourceConfigMap) throws Exception {
        Connection conn = null;
        Statement stmt = null;
        String dbTypeName = dataSourceProperty.getDbTypeName();
        try {
            log.info("load [{}] start", dbTypeName);
            Class.forName(dataSourceProperty.getDriverClassName());
            conn = DriverManager.getConnection(dataSourceProperty.getUrl(), dataSourceProperty.getUsername(), dataSourceProperty.getPassword());
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(dataSourceProperty.getSelectDbSql());
            //TODO get dataSource config
            String url = dataSourceProperty.getUrl();
            int index = 0;
            if(SQL_SERVER.equals(dbTypeName)){
                index = url.indexOf("=") + 1;
            }else if(SYBASE.equals(dbTypeName)){
                index = url.indexOf("/") + 1;
            }
            url = url.substring(0, index);
            while(rs.next()){
                String name = rs.getString("name");
                String username = dataSourceProperty.getUsername();
                String password = dataSourceProperty.getPassword();
                String key = dbTypeName + "_" + name;
                DataSourceProperty addDataSourceProperty = new DataSourceProperty();
                addDataSourceProperty.setPollName(key);
                addDataSourceProperty.setDriverClassName(dataSourceProperty.getDriverClassName());
                addDataSourceProperty.setUrl(url + name);
                addDataSourceProperty.setUsername(username);
                addDataSourceProperty.setPassword(password);
                addDataSourceProperty.setPollName(key);
                log.info("load [{}] db info -> {}", dbTypeName, JSONObject.toJSONString(addDataSourceProperty));
                allDataSourceConfigMap.put(key,addDataSourceProperty);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            if(null != conn){
                JdbcUtils.closeConnection(conn);
            }
            if(null != stmt){
                JdbcUtils.closeStatement(stmt);
            }
        }
    }

}